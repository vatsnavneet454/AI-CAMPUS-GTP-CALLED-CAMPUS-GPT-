<?php
// We still include db.php at the top to ensure the database connection is ready
// for any dynamic content we might add later.
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusConnect - Your Digital Campus</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Header & Navigation -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="#" class="text-2xl font-bold text-gray-800">
                Campus<span class="text-indigo-600">Connect</span>
            </a>
            <div class="hidden md:flex items-center space-x-6">
                <a href="#" class="text-gray-600 hover:text-indigo-600 transition duration-300">Timetables</a>
                <a href="#" class="text-gray-600 hover:text-indigo-600 transition duration-300">Events</a>
                <a href="#" class="text-gray-600 hover:text-indigo-600 transition duration-300">Faculty</a>
            </div>
            <div class="flex items-center space-x-4">
                <a href="login.php" class="text-gray-600 hover:text-indigo-600 transition duration-300">Login</a>
                <a href="signup.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition duration-300 shadow">Sign Up</a>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main>
        <!-- Hero Section -->
        <section class="bg-white">
            <div class="container mx-auto px-6 py-20 text-center">
                <h1 class="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4">
                    Your Entire Campus, Connected.
                </h1>
                <p class="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
                    Access timetables, discover events, and connect with faculty, all in one unified platform.
                </p>
                <a href="#" class="bg-indigo-600 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-indigo-700 transition duration-300 shadow-lg">
                    Get Started
                </a>
            </div>
        </section>

        <!-- Features Section -->
        <section class="py-20">
            <div class="container mx-auto px-6">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">
                    Key Features
                </h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    
                    <!-- Feature 1: Timetables -->
                    <div class="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                        <div class="flex items-center justify-center h-16 w-16 bg-indigo-100 rounded-full mb-6">
                            <!-- SVG Icon: Calendar -->
                            <svg class="h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">View Timetables</h3>
                        <p class="text-gray-600 mb-4">
                            Never miss a class. Access your detailed weekly schedule anytime, anywhere.
                        </p>
                        <a href="#" class="text-indigo-600 font-semibold hover:underline">Learn More &rarr;</a>
                    </div>

                    <!-- Feature 2: Events -->
                    <div class="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                        <div class="flex items-center justify-center h-16 w-16 bg-indigo-100 rounded-full mb-6">
                            <!-- SVG Icon: Megaphone -->
                            <svg class="h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                               <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-2.236 9.168-5.514C18.332 18.885 15.12 22 11 22h-1c-2.838 0-5.463-1.447-7-3.683z"/>
                            </svg>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">Upcoming Events</h3>
                        <p class="text-gray-600 mb-4">
                            Stay updated with the latest workshops, seminars, and fests happening on campus.
                        </p>
                        <a href="#" class="text-indigo-600 font-semibold hover:underline">Explore Events &rarr;</a>
                    </div>

                    <!-- Feature 3: Faculty Directory -->
                    <div class="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                        <div class="flex items-center justify-center h-16 w-16 bg-indigo-100 rounded-full mb-6">
                            <!-- SVG Icon: Users -->
                            <svg class="h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">Faculty Directory</h3>
                        <p class="text-gray-600 mb-4">
                            Easily find contact information and professional details for all faculty members.
                        </p>
                        <a href="#" class="text-indigo-600 font-semibold hover:underline">Find Faculty &rarr;</a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t">
        <div class="container mx-auto px-6 py-4">
            <p class="text-center text-gray-500">
                &copy; <?php echo date("Y"); ?> CampusConnect. All Rights Reserved.
            </p>
        </div>
    </footer>

</body>
</html>


