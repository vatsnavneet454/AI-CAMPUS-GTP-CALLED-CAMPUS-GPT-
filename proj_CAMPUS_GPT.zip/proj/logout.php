<?php
// 1. Initialize the session
// It's necessary to start the session in order to access and destroy it.
session_start();

// 2. Unset all of the session variables
// $_SESSION = array(); frees all session variables currently registered.
$_SESSION = array();

// 3. Destroy the session.
// This will remove the session data from the server.
session_destroy();

// 4. Redirect to login page
// After logging out, the user should be sent back to the login page.
header("location: login.php");
exit; // It's crucial to call exit() after a header redirect to stop script execution.
?>

