<?php
// --- SESSION MANAGEMENT & AUTHENTICATION ---
session_start();

// STEP 1: Check if the user is a teacher. This is the security check you requested.
// If the user is not logged in OR their role is not 'teacher', they are redirected.
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php"); // Redirect non-teachers
    exit();
}

// --- INCLUDE DATABASE CONNECTION ---
require_once 'db.php';

// --- INITIALIZE VARIABLES ---
$error_message = '';
$success_message = '';

// --- HANDLE THE "REMOVE" ACTION ---
// This block runs only when a teacher clicks the 'Delete' button on a faculty member.
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_faculty'])) {
    
    // Get the user_id of the faculty member to be removed.
    $user_id_to_delete = $_POST['user_id'];

    if (!empty($user_id_to_delete)) {
        // We delete the user from the 'users' table.
        // Because of the 'ON DELETE CASCADE' rule in your database,
        // deleting the user will automatically delete their linked faculty record.
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'teacher'");
        $stmt->bind_param("i", $user_id_to_delete);
        
        if ($stmt->execute()) {
            $success_message = "Faculty member and their user account have been removed successfully.";
        } else {
            $error_message = "Error removing faculty member.";
        }
        $stmt->close();
    }
}

// --- FETCH ALL FACULTY DETAILS FOR DISPLAY ---
// This query gets all faculty members and joins with the users table to get the correct user ID for deletion.
$faculty_list = [];
$result = $conn->query("SELECT f.*, u.id as user_id_for_delete FROM faculty f JOIN users u ON f.user_id = u.id ORDER BY f.name ASC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $faculty_list[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Faculty - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">

    <header class="bg-white shadow-sm sticky top-0 z-10">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
             <a href="dashboard.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
            <a href="dashboard.php" class="text-sm font-semibold text-indigo-600 hover:underline">← Back to Dashboard</a>
        </div>
    </header>

    <main class="container mx-auto p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Faculty Directory Management</h1>

        <!-- Display Messages -->
        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6" role="alert">
                <span><?php echo $error_message; ?></span>
            </div>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
             <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-6" role="alert">
                <span><?php echo $success_message; ?></span>
            </div>
        <?php endif; ?>

        <!-- STEP 2: Show all faculty details in a table -->
        <div class="bg-white p-6 rounded-lg shadow-md">
             <h2 class="text-xl font-bold text-gray-700 mb-4 border-b pb-2">Current Faculty Members</h2>
             <p class="text-sm text-gray-600 mb-4">Faculty members are automatically added when a 'teacher' account is created. You can view and remove them here.</p>
             <div class="overflow-x-auto">
                 <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subjects Taught</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (!empty($faculty_list)): ?>
                            <?php foreach ($faculty_list as $member): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($member['name']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <div><?php echo htmlspecialchars($member['email']); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo htmlspecialchars($member['phone'] ?? 'N/A'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($member['subjects'] ?? 'Not specified'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($member['sitting_location'] ?? 'Not specified'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                        <!-- STEP 3: Add the option to remove them -->
                                        <form action="manage_faculty.php" method="POST" onsubmit="return confirm('Are you sure you want to remove this faculty member? This will also delete their user account.');">
                                            <input type="hidden" name="user_id" value="<?php echo $member['user_id_for_delete']; ?>">
                                            <button type="submit" name="delete_faculty" class="text-red-600 hover:text-red-900">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="px-6 py-4 text-center text-gray-500">No faculty members found. They are added automatically upon teacher registration.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
             </div>
        </div>
    </main>
</body>
</html>