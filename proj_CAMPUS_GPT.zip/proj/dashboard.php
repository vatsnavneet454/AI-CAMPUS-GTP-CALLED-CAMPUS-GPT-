<?php
// --- SESSION MANAGEMENT & AUTHENTICATION ---
session_start();

// If the user is not logged in, redirect them to the login page
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// --- INCLUDE DATABASE CONNECTION ---
require_once 'db.php';

// --- GATHER USER INFORMATION FROM SESSION ---
// Use 'name' which is set during login, instead of the old 'username'
$user_id = $_SESSION['id'];
$name = $_SESSION['name']; 
$role = $_SESSION['role'];
$course = isset($_SESSION['course']) ? $_SESSION['course'] : 'N/A';
$subjects_string = isset($_SESSION['subjects']) ? $_SESSION['subjects'] : '';
$subjects = !empty($subjects_string) ? array_map('trim', explode(',', $subjects_string)) : [];


// --- DYNAMIC GREETING ---
$current_hour = date('H');
if ($current_hour < 12) {
    $greeting = "Good Morning";
} elseif ($current_hour < 18) {
    $greeting = "Good Afternoon";
} else {
    $greeting = "Good Evening";
}

// --- FETCH DATA FROM DATABASE ---
$timetable_result = $conn->query("SELECT * FROM timetables ORDER BY start_time ASC");
$events_result = $conn->query("SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC");
$exams_result = $conn->query("SELECT * FROM exams WHERE exam_date >= CURDATE() ORDER BY exam_date ASC");
$faculty_result = $conn->query("SELECT * FROM faculty ORDER BY name ASC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">

    <!-- Header -->
    <header class="bg-white shadow-sm sticky top-0 z-10">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="dashboard.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
            <div class="flex items-center space-x-4">
                <!-- Correctly display the user's name -->
                <span class="text-gray-600">Welcome, <span class="font-semibold"><?php echo htmlspecialchars($name); ?></span>!</span>
                <a href="logout.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md transition duration-300">Logout</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-6 py-8">
        
        <div class="bg-indigo-600 text-white p-6 rounded-lg shadow-lg mb-8">
            <!-- Correctly display the user's name in the greeting -->
            <h1 class="text-3xl font-bold"><?php echo $greeting . ", " . htmlspecialchars($name); ?>!</h1>
            <p class="mt-2">Your role is: <span class="font-semibold capitalize bg-white text-indigo-600 px-2 py-1 rounded-full text-sm"><?php echo htmlspecialchars($role); ?></span></p>
        </div>

        <!-- Role-Based Content -->
        <?php if ($role == 'student'): ?>
            <!-- ================== STUDENT VIEW ================== -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                
                <!-- My Course & Subjects Card -->
                <div class="md:col-span-2 lg:col-span-3 bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">My Academics</h2>
                    <div class="flex flex-col md:flex-row gap-4">
                        <div class="flex-1">
                            <h3 class="text-gray-500 font-semibold text-sm">COURSE</h3>
                            <p class="text-indigo-600 font-bold text-lg"><?php echo htmlspecialchars($course); ?></p>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-gray-500 font-semibold text-sm">SUBJECTS</h3>
                            <div class="flex flex-wrap gap-2 mt-2">
                                <?php if (!empty($subjects)): ?>
                                    <?php foreach($subjects as $subject): ?>
                                        <span class="bg-gray-200 text-gray-800 text-xs font-semibold px-2.5 py-1 rounded-full"><?php echo htmlspecialchars($subject); ?></span>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-sm text-gray-500">No subjects listed.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Exams Card -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Upcoming Exams</h2>
                    <ul class="space-y-3">
                        <?php if ($exams_result && $exams_result->num_rows > 0): ?>
                            <?php while($exam = $exams_result->fetch_assoc()): ?>
                                <li class="p-3 bg-gray-50 rounded-md border border-gray-200">
                                    <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($exam['subject']); ?></p>
                                    <p class="text-xs text-gray-500 mt-1"><?php echo date('F j, Y', strtotime($exam['exam_date'])) . ' at ' . date('g:i A', strtotime($exam['start_time'])); ?></p>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="text-center text-gray-500">No upcoming exams.</li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Events Card -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Campus Events</h2>
                    <ul class="space-y-3">
                        <?php if ($events_result && $events_result->num_rows > 0): ?>
                             <?php while($event = $events_result->fetch_assoc()): ?>
                                <li class="p-3 bg-gray-50 rounded-md border border-gray-200">
                                    <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($event['title']); ?></p>
                                    <p class="text-xs text-gray-500 mt-1"><?php echo date('F j, Y, g:i A', strtotime($event['event_date'])); ?></p>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="text-center text-gray-500">No upcoming events.</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Timetable Card -->
                <div class="lg:col-span-3 bg-white p-6 rounded-lg shadow-md">
                     <h2 class="text-xl font-bold text-gray-800 mb-4">Full Schedule</h2>
                     <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php if ($timetable_result && $timetable_result->num_rows > 0): ?>
                                    <?php while($row = $timetable_result->fetch_assoc()): ?>
                                        <tr>
                                            <td class="px-4 py-3 text-sm text-gray-700"><?php echo date('g:i A', strtotime($row['start_time'])) . ' - ' . date('g:i A', strtotime($row['end_time'])); ?></td>
                                            <td class="px-4 py-3 font-medium text-gray-900"><?php echo htmlspecialchars($row['subject']); ?></td>
                                            <td class="px-4 py-3 text-sm text-gray-500"><?php echo htmlspecialchars($row['location']); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" class="px-4 py-3 text-center text-gray-500">No classes scheduled.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        <?php else: ?>
            <!-- ================== TEACHER VIEW ================== -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-2 space-y-8">
                    <!-- Management Links -->
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-xl font-bold text-gray-800 mb-4">Management Panel</h2>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                            <a href="manage_timetable.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-4 rounded-md text-center">Manage Timetable</a>
                            <a href="manage_exams.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-4 rounded-md text-center">Manage Exams</a>
                            <a href="manage_events.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-4 rounded-md text-center">Manage Events</a>
                        </div>
                    </div>
                    <!-- Timetable and Events can be shown here if needed -->
                </div>
                 <!-- Faculty Directory -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex justify-between items-center mb-4">
                         <h2 class="text-xl font-bold text-gray-800">Faculty Directory</h2>
                         <a href="manage_faculty.php" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-3 rounded-md text-sm">Manage Faculty</a>
                    </div>
                    <ul class="space-y-3">
                        <?php if ($faculty_result && $faculty_result->num_rows > 0): ?>
                            <?php while($member = $faculty_result->fetch_assoc()): ?>
                                <li>
                                    <div class="flex items-center space-x-3">
                                        <div class="flex-shrink-0 h-10 w-10 bg-indigo-200 text-indigo-700 font-bold rounded-full flex items-center justify-center">
                                            <?php echo strtoupper(substr($member['name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <p class="text-sm font-semibold text-gray-900"><?php echo htmlspecialchars($member['name']); ?></p>
                                            <p class="text-xs text-gray-500"><?php echo htmlspecialchars($member['department']); ?></p>
                                        </div>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="text-center text-gray-500">No faculty members found.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>

