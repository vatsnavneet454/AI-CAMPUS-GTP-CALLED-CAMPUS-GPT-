<?php
// --- DATABASE CONFIGURATION ---
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "campus_gpt_db";

// --- 1. ESTABLISH CONNECTION ---
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- 2. CREATE DATABASE IF IT DOESN'T EXIST ---
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);

// --- 3. DEFINE TABLE STRUCTURES ---

// Table: users (with all the new fields)
$sql_users = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    registration_id VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'teacher') NOT NULL,
    course VARCHAR(100),
    subjects TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;";

// Table: faculty (with teacher's location)
$sql_faculty = "CREATE TABLE IF NOT EXISTS faculty (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    position VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    sitting_location VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;";

// Table: timetables
$sql_timetables = "CREATE TABLE IF NOT EXISTS timetables (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(100) NOT NULL,
    day_of_week VARCHAR(15) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    subject VARCHAR(100) NOT NULL,
    faculty_id INT(11) UNSIGNED,
    location VARCHAR(100),
    FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE SET NULL
) ENGINE=InnoDB;";

// Table: events
$sql_events = "CREATE TABLE IF NOT EXISTS events (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_date DATETIME NOT NULL,
    location VARCHAR(255)
) ENGINE=InnoDB;";

// Table: exams (with course and teacher_id)
$sql_exams = "CREATE TABLE IF NOT EXISTS exams (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(100) NOT NULL,
    exam_date DATE NOT NULL,
    start_time TIME NOT NULL,
    location VARCHAR(100),
    course VARCHAR(100) NOT NULL,
    teacher_id INT(11) UNSIGNED,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;";


// --- 4. EXECUTE TABLE CREATION ---
$tables_to_create = [
    'users' => $sql_users,
    'faculty' => $sql_faculty,
    'timetables' => $sql_timetables,
    'events' => $sql_events,
    'exams' => $sql_exams
];

foreach ($tables_to_create as $table_name => $sql) {
    if (!$conn->query($sql)) {
        die("Error creating table '{$table_name}': " . $conn->error);
    }
}
?>

