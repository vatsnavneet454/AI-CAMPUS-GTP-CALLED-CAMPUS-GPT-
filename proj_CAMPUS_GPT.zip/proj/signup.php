<?php
// --- SESSION MANAGEMENT ---
session_start();
if (isset($_SESSION['id'])) {
    header("Location: dashboard.php");
    exit();
}

// --- INCLUDE DATABASE CONNECTION ---
require_once 'db.php';

// --- VARIABLE INITIALIZATION ---
$error_message = '';
$success_message = '';

// --- FORM SUBMISSION HANDLING ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Start a transaction to ensure both inserts succeed or fail together
    $conn->begin_transaction();

    try {
        // --- GET AND SANITIZE FORM DATA ---
        $registration_id = $conn->real_escape_string(trim($_POST['registration_id']));
        $name = $conn->real_escape_string(trim($_POST['name']));
        $email = $conn->real_escape_string(trim($_POST['email']));
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST['confirm_password']);
        $role = $_POST['role'];
        $course = ($role === 'student') ? $conn->real_escape_string(trim($_POST['course'])) : null;
        $subjects = $conn->real_escape_string(trim($_POST['subjects']));

        // --- FORM VALIDATION ---
        if (empty($registration_id) || empty($name) || empty($email) || empty($password) || empty($role) || empty($subjects)) {
            throw new Exception("Please fill in all required fields.");
        }
        if ($password !== $confirm_password) {
            throw new Exception("Passwords do not match.");
        }
        if (strlen($password) < 6) {
            throw new Exception("Password must be at least 6 characters long.");
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format.");
        }

        // --- CHECK FOR EXISTING USER ---
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ? OR registration_id = ?");
        $stmt_check->bind_param("ss", $email, $registration_id);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        if ($result->num_rows > 0) {
            throw new Exception("Email or Registration ID already exists.");
        }
        $stmt_check->close();

        // --- STEP 1: INSERT INTO 'users' TABLE ---
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt_user = $conn->prepare("INSERT INTO users (registration_id, name, email, password, role, course, subjects) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_user->bind_param("sssssss", $registration_id, $name, $email, $hashed_password, $role, $course, $subjects);
        
        if (!$stmt_user->execute()) {
            throw new Exception("Error creating user account.");
        }

        // --- STEP 2: IF TEACHER, INSERT INTO 'faculty' TABLE ---
        if ($role === 'teacher') {
            // Get the ID of the user we just created
            $new_user_id = $conn->insert_id;

            // Now, insert a corresponding record into the faculty table
            $stmt_faculty = $conn->prepare("INSERT INTO faculty (user_id, name, email) VALUES (?, ?, ?)");
            $stmt_faculty->bind_param("iss", $new_user_id, $name, $email);

            if (!$stmt_faculty->execute()) {
                throw new Exception("Error creating faculty profile.");
            }
            $stmt_faculty->close();
        }
        
        $stmt_user->close();

        // If everything was successful, commit the transaction
        $conn->commit();
        $success_message = "Account created successfully! You can now <a href='login.php' class='font-bold text-indigo-600 hover:underline'>log in</a>.";

    } catch (Exception $e) {
        // If any step failed, roll back the transaction
        $conn->rollback();
        $error_message = $e->getMessage();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .form-row-hidden { display: none; }
    </style>
</head>
<body class="bg-gray-50">
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
             <a href="index.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
        </nav>
    </header>
    <main class="flex justify-center items-center py-12 px-6">
        <div class="w-full max-w-lg bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Create Your Account</h2>
            
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-4" role="alert">
                    <span><?php echo $error_message; ?></span>
                </div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                 <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-4" role="alert">
                    <span><?php echo $success_message; ?></span>
                </div>
            <?php endif; ?>

            <form action="signup.php" method="POST">
                <!-- Role Selection -->
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2">I am a...</label>
                    <div class="flex items-center space-x-4">
                        <label class="inline-flex items-center">
                            <input type="radio" class="form-radio text-indigo-600" name="role" value="student" checked onchange="toggleCourse(this.value)">
                            <span class="ml-2 text-gray-700">Student</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" class="form-radio text-indigo-600" name="role" value="teacher" onchange="toggleCourse(this.value)">
                            <span class="ml-2 text-gray-700">Teacher</span>
                        </label>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="mb-4">
                        <label for="registration_id" class="block text-gray-700 text-sm font-bold mb-2">Registration ID</label>
                        <input type="text" id="registration_id" name="registration_id" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="e.g., 20BCE1234">
                    </div>
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Full Name</label>
                        <input type="text" id="name" name="name" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="John Doe">
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address</label>
                    <input type="email" id="email" name="email" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="you@example.com">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="mb-4">
                        <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                        <input type="password" id="password" name="password" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="Min. 6 characters">
                    </div>
                    <div class="mb-4">
                        <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700">
                    </div>
                </div>

                <div id="course-row" class="mb-4">
                    <label for="course" class="block text-gray-700 text-sm font-bold mb-2">Course</label>
                    <input type="text" id="course" name="course" class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="e.g., Computer Science">
                </div>

                <div class="mb-6">
                    <label for="subjects" class="block text-gray-700 text-sm font-bold mb-2">Subjects</label>
                    <input type="text" id="subjects" name="subjects" required class="shadow appearance-none border rounded-md w-full py-2 px-3 text-gray-700" placeholder="Comma-separated, e.g., Math, Physics">
                    <p class="text-xs text-gray-500 mt-1" id="subjects-helper">For students, list your subjects. For teachers, list subjects you teach.</p>
                </div>

                <div class="flex items-center justify-between">
                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-md transition duration-300">
                        Create Account
                    </button>
                </div>
            </form>
            
            <p class="text-center text-gray-600 text-sm mt-6">
                Already have an account? 
                <a href="login.php" class="font-bold text-indigo-600 hover:text-indigo-800">Log in</a>
            </p>
        </div>
    </main>
    <script>
        function toggleCourse(role) {
            const courseRow = document.getElementById('course-row');
            if (role === 'student') {
                courseRow.style.display = 'block';
            } else {
                courseRow.style.display = 'none';
            }
        }
        // Initial check
        toggleCourse('student');
    </script>
</body>
</html>